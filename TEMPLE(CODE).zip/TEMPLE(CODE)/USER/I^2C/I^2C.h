#ifndef __I2C_
#define __I2C_

#include "stm32f10x.h"
#include "Define.h"

//STM32   ���豸��ַ
#define   STM32_I2C_OWN_ADDR     0x5f
//RDA5807 ���豸��ַ
#define   RDA5807_I2C_SLAVE_ADDR 0x22

void     I2C_RDA5807M_Config (void);
void     RDA5807M_HWord_Write(uint8_t addr, uint16_t data);
uint16_t RDA5807M_HWord_Read (uint8_t addr);

#endif
