#ifndef __DEFINE_H
#define __DEFINE_H

#include "stm32f10x.h"

//���Դ���ʹ��USART1
//STM32   CH340(ETC..)
// A9----->RXD
// A10---->TXD
// ����1-USART1
#define  DEBUG_USART                    USART1
#define  DEBUG_USART_CLK                RCC_APB2Periph_USART1
#define  DEBUG_USART_BAUDRATE           115200

//USART1 ���ź궨��
#define  DEBUG_USART_GPIO_CLK           (RCC_APB2Periph_GPIOA)
#define  DEBUG_USART_TX_GPIO_PORT       GPIOA   
#define  DEBUG_USART_TX_GPIO_PIN        GPIO_Pin_9
#define  DEBUG_USART_RX_GPIO_PORT       GPIOA
#define  DEBUG_USART_RX_GPIO_PIN        GPIO_Pin_10

//RDA5807Mʹ��I^2C1
//STM32   RDA5807M
// B10----->SCL
// B11----->SDA
#define  RDA5807M_I2C                   I2C2
#define  RDA5807M_I2C_CLK               RCC_APB1Periph_I2C2
#define  RDA5807M_I2C_BAUDRATE          100000

//I^2C ���ź궨��
#define  RDA5807M_I2C_SCL_GPIO_CLK      (RCC_APB2Periph_GPIOB)
#define  RDA5807M_I2C_SDA_GPIO_CLK      (RCC_APB2Periph_GPIOB)

#define  RDA5807M_I2C_SCL_GPIO_PORT      GPIOB  
#define  RDA5807M_I2C_SCL_GPIO_PIN       GPIO_Pin_10
#define  RDA5807M_I2C_SDA_GPIO_PORT      GPIOB
#define  RDA5807M_I2C_SDA_GPIO_PIN       GPIO_Pin_11

#endif
